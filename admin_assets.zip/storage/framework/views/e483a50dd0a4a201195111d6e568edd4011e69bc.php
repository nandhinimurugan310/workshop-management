

<?php $__env->startSection('content'); ?>

<style>
    .column-container {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
    }

    .column {
        width: 48%;
    }

    .card {
        max-width: 100%; /* Ensure the card adjusts its width to the page */
        width: 100%; /* Ensure the card takes up the full width of its container */
        height: auto; /* Set height to auto to adjust dynamically */
    }

    .card-section {
        border-right: 1px solid #ccc; /* Add border between sections */
        padding-right: 10px; /* Add padding to separate border from content */
    }

    .card-section:last-child {
        border-right: none; /* Remove border from last section */
    }

    table {
        border-collapse: collapse;
        width: 100%;
    }

    th,
    td {
        border: 1px solid #ccc;
        padding: 8px;
        text-align: left;
    }

    tr:nth-child(even) {
        background-color: #f2f2f2;
    }
 .blue-button {
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center; /* Align text at the center */
    text-decoration: none; /* Remove underline */
    color: white;
    padding: 10px 20px;
    background-color: #385170;
    border-radius: 5px;
    font-weight: bold; /* Make the text bold */
}
button {
    background-color: purple;
    color: white;
    padding: 8px 16px; /* Adjust padding to reduce button size */
    border: none;
    border-radius: 5px;
    text-decoration: none;
    display: inline-block;
    margin-top: 5px; /* Adjust margin as needed */
    cursor: pointer;
    font-size: 14px; /* Adjust font size */
}

</style>
<div class="card">
    <div class="card-header">
    <a href="#" class="blue-button"><h3>Store- Check Material</h3></a>
        <!-- <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Vehicle Service Analysis</a></li>
                <li class="breadcrumb-item active" aria-current="page">Create Service Analysis</li>
            </ol>
        </nav> -->
    </div>


 

        <!-- Right side, initially hidden -->
         <div class="card-body"> <!-- Added card-body wrapper -->
        <!-- Search input -->
        <label for="searchInput" class="highlight">Search by Vehicle Number:</label>
        <input type="text" id="searchInput">
        <button id="searchButton">Search</button>

       <!-- Right side, initially hidden -->
       <div id="searchResultsContainer" class="card mt-3" style="display:none;">
    <div class="card-body">
        <div class="row">
            <div class="col-md-9">
                <div class="row">
                    <!-- Vehicle details -->
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <h6 class="card-title">Vehicle Number</h6>
                                <p class="card-text">TN O7 BS 7571</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Customer Name</h5>
                                <p class="card-text">Raju</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Contact Number</h5>
                                <p class="card-text">9876543212</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- Second Row: Vehicle Type, Reviewed By, Review Date -->
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Reviewed By</h5>
                                <p class="card-text">Sub-Manager</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Review Date</h5>
                                <p class="card-text">2024-05-16</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Vehicle Type</h5>
                                <p class="card-text">TATA-ACE</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-3">
                <!-- Image -->
                <img src="<?php echo e(asset('assets/images/image2.jpeg')); ?>" class="img-fluid" alt="Vehicle Image">
            </div>
        </div>

        <!-- Table -->
        <table id="materialTable" class="mt-3">
            <thead>
                <tr>
                    <th>Material</th>
                    <th>Quantity</th>
                    <th>Unit of Measurement</th>
                    <th>Quantity Received</th>
                    <th>Quantity Short of</th>
                    <th>Brand Expected</th>
                    <th>Brand Received</th>
                    <th>Price</th>
                    <th>Date Received</th>
                    <th>Materials Checked By</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Bumper</td>
                    <td>10</td>
                    <td>Pcs</td>
                    <td>8</td>
                    <td>2</td>
                    <td>Toyoto</td>
                    <td>Toyoto</td>
                    <td>₹50</td>
                    <td>2024-05-10</td>
                    <td>ARUN</td>
                </tr>
                <tr>
                    <td>Side window</td>
                    <td>20</td>
                    <td>Pcs</td>
                    <td>18</td>
                    <td>2</td>
                    <td>TATA</td>
                    <td>Suzuki</td>
                    <td>₹100</td>
                    <td>2024-05-11</td>
                    <td>JAGAN</td>
                </tr>
                <!-- Add more rows as needed -->
            </tbody>
        </table>
        <div>
            <button>Edit</button>
            <button>Save</button>
        </div>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.getElementById("searchButton").addEventListener("click", function () {
            // Show the search results container
            document.getElementById("searchResultsContainer").style.display = "block";
            // Show the buttons and table container
            document.getElementById("buttonTableContainer").style.display = "block";
        });
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zp2lanbzry82/website.ospdemo.in/resources/views/admin/productstock.blade.php ENDPATH**/ ?>