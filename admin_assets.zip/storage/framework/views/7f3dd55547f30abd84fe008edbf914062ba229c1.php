<div class="nav-align-left mb-6">
    <ul class="nav nav-pills me-4" role="tablist">
        <?php $__currentLoopData = $groupedAllocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplierId => $allocations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($supplierId): ?>
                <?php 
                    $vendor_id = $allocations->first()->vendor_id; 
                ?>
                <li class="nav-item" role="presentation">
                    <button type="button" class="nav-link waves-effect waves-light newupdate "
                            role="tab" data-bs-toggle="tab" data-bs-target="#supplier<?php echo e($supplierId); ?>"
                            aria-controls="supplier<?php echo e($supplierId); ?>"
                            aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>"
                            tabindex="-1"><?php echo e($vendor_id); ?></button>
                </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="tab-content">
        <?php $__currentLoopData = $groupedAllocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplierId => $allocations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($supplierId): ?>
            <?php 
                    $vendor_name = $allocations->first()->vendor_name; 
                ?>
                <div class="tab-pane fade <?php if($loop->first): ?> show active <?php endif; ?>" id="supplier<?php echo e($supplierId); ?>" role="tabpanel">

                    <h5>supplier:<?php echo e($vendor_name); ?></h5>
                    <table class="table table-striped table-bordered mt-4 pt-4 dataTable no-footer">
                        <thead class="bg-primary">
                            <tr>
                                <th scope="col" style="color:white;font-size:medium;text-align:center">Material Name</th>
                                <th scope="col" style="color:white;font-size:medium;text-align:center">Brand</th>
                                <th scope="col" style="color:white;font-size:medium;text-align:center">Quantity</th>
                                <th scope="col" style="color:white;font-size:medium;text-align:center">Unit</th>
                                <th scope="col" style="color:white;font-size:medium;text-align:center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $allocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($allocation->material_name); ?></td>
                                    <td><?php echo e($allocation->brand); ?></td>
                                    <td><?php echo e($allocation->quantity); ?></td>
                                    <td><?php echo e($allocation->unit_of_measurement); ?></td>
                                    <td>
                                         <button type="button" class="btn rounded-pill btn-outline-primary waves-effect delete-button" data-supplier-id="<?php echo e($allocation->id); ?>">
                                            <i class="mdi mdi-trash-can-outline me-1"></i> Delete
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<script>
    $(document).ready(function() {
        // Activate the first tab-pane
        $('.tab-pane').first().addClass('show active');
        $('.newupdate').first().addClass('active');

        // Initialize DataTables for all tables with the 'table' class
        $('.table').DataTable();
    });
</script>
<script>
    $(document).ready(function() {
        // Handle delete button click
        $('.delete-button').click(function() {
            var supplierId = $(this).data('supplier-id');
            
            // Perform AJAX request to delete the supplier
            $.ajax({
                url: "<?php echo e(route('delete.supplier')); ?>",
                type: 'POST',
                data: { 
                    supplierId: supplierId,
                    // Include CSRF token in the request data
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                success: function(response) {
                  fetchSupplierList(<?php echo e($vehicleNumber); ?>);
                },
                error: function(xhr, status, error) {
                    // Handle error response
                    console.error('Error deleting supplier: ' + error);
                }
            });
        });
    });
</script><?php /**PATH /home/zp2lanbzry82/website.ospdemo.in/resources/views/purchase_order/supplier_list.blade.php ENDPATH**/ ?>