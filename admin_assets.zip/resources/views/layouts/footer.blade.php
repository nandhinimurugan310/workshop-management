<div class="container-fluid copyright text-light py-4 wow fadeIn" data-wow-delay="0.1s">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="text-primary">Sakthi Body Works</a>, All Right Reserved,2024.
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        Developed By <a class="text-primary"> Accelerated Development Machines</a>
                    </div>
                </div>
            </div>
        </div>
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>