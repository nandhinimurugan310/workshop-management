

<?php $__env->startSection('content'); ?>

<style>

.form-group {
    margin-bottom: 20px;
    display: flex;
    align-items: center;
}

label {
    flex: 1;
    margin-right: 10px;
}

input[type="text"],
input[type="number"],
select,
textarea,
input[type="date"] {
    flex: 2;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    width: 100%; /* Make sure the input fields take full width */
}

.card {
    width: 100%;
    height: 100vh;
    margin: auto;
    overflow: auto; /* Add overflow to enable scrolling if content exceeds height */
}

.form-container {
    padding: 20px;
}

/* Additional styling for form elements as needed */
.form-group {
    margin-bottom: 20px;
}

button[type="submit"] {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
}

button[type="submit"]:hover {
    background-color: #0056b3;
}

.blue-button {
    background-color: blue;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    text-decoration: none;
    display: block; /* Change display property to block */
    width: 100%; /* Set width to 100% */
    box-sizing: border-box; /* Ensure padding is included in the width */
    text-align: left; /* Align text to the right */
}
</style>
<div class="card">
    <div class="card-header">
    <a href="#" class="blue-button"><h3>Material Return Form</h3></a>
        <!-- <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Vehicle Service Analysis</a></li>
                <li class="breadcrumb-item active" aria-current="page">Create Service Analysis</li>
            </ol>
        </nav> -->
    </div>


    <div class="form-container">
        <form action="#" method="post">
            <div class="form-group">
                <label for="material_name">Material Name:</label>
                <input type="text" id="material_name" name="material_name" required>
            </div>
            <div class="form-group">
                <label for="brand">Brand:</label>
                <select id="brand" name="brand" required>
                    <option value="brand1">Brand 1</option>
                    <option value="brand2">Brand 2</option>
                    <!-- Add more options as needed -->
                </select>
            </div>
            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" required>
            </div>
            <div class="form-group">
                <label for="unit_of_measurement">Unit of Measurement:</label>
                <input type="text" id="unit_of_measurement" name="unit_of_measurement" required>
            </div>
            <div class="form-group">
                <label for="date_of_return">Date of Return:</label>
                <input type="date" id="date_of_return" name="date_of_return" required>
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea id="description" name="description" rows="4"></textarea>
            </div>
            <button type="submit">Save</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sakthi body works\sakthi\resources\views/user/return.blade.php ENDPATH**/ ?>