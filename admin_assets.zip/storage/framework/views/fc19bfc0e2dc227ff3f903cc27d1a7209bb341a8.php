

<?php $__env->startSection('content'); ?>

<style>

.form-group {
    margin-bottom: 20px;
    display: flex;
    align-items: center;
}

label {
    flex: 1;
    margin-right: 10px;
}

input[type="text"],
input[type="number"],
select,
textarea,
input[type="date"] {
    flex: 2;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box;
    width: 100%; /* Make sure the input fields take full width */
}

.card {
    width: 100%;
    height: 100vh;
    margin: auto;
    overflow: auto; /* Add overflow to enable scrolling if content exceeds height */
}

.form-container {
    padding: 20px;
}

/* Additional styling for form elements as needed */
.form-group {
    margin-bottom: 20px;
}

button[type="submit"] {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 4px;
    cursor: pointer;
}

button[type="submit"]:hover {
    background-color: #0056b3;
}

.blue-button {
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center; /* Align text at the center */
    text-decoration: none; /* Remove underline */
    color: white;
    padding: 10px 20px;
    background-color: #385170;
    border-radius: 5px;
    font-weight: bold; /* Make the text bold */
}
</style>
<div class="card">
    <div class="card-header">
    <a href="#" class="blue-button"><h3>Material Return Form</h3></a>
        <!-- <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Vehicle Service Analysis</a></li>
                <li class="breadcrumb-item active" aria-current="page">Create Service Analysis</li>
            </ol>
        </nav> -->
    </div>


    <div class="form-container">
        <form action="#" method="post">
            <div class="form-group">
                <label for="material_name">Material Name:</label>
                <input type="text" id="material_name" name="material_name" value="headlight" required>
            </div>
            <div class="form-group">
                <label for="brand">Brand:</label>
                <select id="brand" name="brand" required>
                    <option value="brand1">Brand 1</option>
                    <option value="brand2">Brand 2</option>
                    <!-- Add more options as needed -->
                </select>
            </div>
            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" value="2" required>
            </div>
            <div class="form-group">
                <label for="unit_of_measurement">Unit of Measurement:</label>
                <input type="text" id="unit_of_measurement" name="unit_of_measurement" value="piece" required>
            </div>
            <div class="form-group">
                <label for="date_of_return">Date of Return:</label>
                <input type="date" id="date_of_return" name="date_of_return" required>
            </div>
<div class="form-group">
    <label for="description">Description:</label>
    <textarea id="description" name="description" rows="4">The headlight, an essential component of any vehicle, serves as the eyes of the automobile, illuminating the road ahead and ensuring safe travel during dimly lit conditions.</textarea>
</div>

            <button type="submit">Save</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zp2lanbzry82/website.ospdemo.in/resources/views/admin/return.blade.php ENDPATH**/ ?>