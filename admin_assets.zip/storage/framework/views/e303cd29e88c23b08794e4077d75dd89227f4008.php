
<?php $__env->startSection('content1'); ?>
    <!-- Page Header Start -->
    <div class="container-fluid page-header py-6 my-1 mt-0 wow fadeIn" data-wow-delay="0.1s">
        <div class="container text-center">           
            <nav aria-label="breadcrumb animated slideInDown">
                
            </nav>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Contact Start -->
    <div class="container-xxl py-4">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 450px;">
                    <div class="position-relative h-100">
                        <iframe class="position-relative w-100 h-100"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3001156.4288297426!2d-78.01371936852176!3d42.72876761954724!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4ccc4bf0f123a5a9%3A0xddcfc6c1de189567!2sNew%20York%2C%20USA!5e0!3m2!1sen!2sbd!4v1603794290143!5m2!1sen!2sbd"
                        frameborder="0" style="min-height: 450px; border:0;" allowfullscreen="" aria-hidden="false"
                        tabindex="0"></iframe>
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                    <h1 class="text-primary text-uppercase mb-2">Contact Us</h1>
                    <div class="col-lg-12 col-md-6">                       
                        <p class="mb-2" style="font-size:x-large;"><i class="fa fa-map-marker-alt me-3"></i>No.46, Poonamallee bye pass road Poonamallee Chennai 56</p>
                        <p class="mb-2" style="font-size:x-large;"><i class="fa fa-phone-alt me-3"></i>9884055853</p>
                        <p class="mb-2" style="font-size:x-large;"><i class="fa fa-envelope me-3"></i>sakthibodyworks@gmail.com </p>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- Contact End -->

    <?php $__env->stopSection(); ?>


    
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sakthi body works\sakthi\resources\views/user/contact.blade.php ENDPATH**/ ?>