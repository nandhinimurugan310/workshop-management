

<?php $__env->startSection('content'); ?>

<style>
    body, html {
        height: 100%;
        margin: 0;
    }

    .search-form {
        display: flex;
        align-items: center; /* Align items vertically */
        margin-bottom: 20px; /* Add margin for spacing */
    }

    .search-form .form-group {
        margin-right: 10px;
        flex: 1; /* Use flex-grow to allow the form groups to expand */
    }

    .search-form .form-group:last-child {
        margin-right: 0; /* Remove margin from the last form group */
    }

    .search-form .form-group label {
        margin-right: 5px;
    }

    .search-form .form-control {
        width: 60%; /* Make the inputs take up the full width of their container */
    }

    /* Set card height to 100% */
    .card {
        height: 100%;
        width: 100%;
    }

    /* Set card body height to 100% */
    .card-body {
        height: calc(100% - 160px); /* Adjust based on header height and margins */
        overflow-y: auto; /* Add vertical scrollbar if content overflows */
    }

    /* Set table height to 70% of card body height */
    .table {
        height: 50%;
    }

    /* Set table body height to 100% of table height */
    .table tbody {
        height: 100%;
        overflow-y: auto; /* Add vertical scrollbar if content overflows */
    }

 .blue-button {
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center; /* Align text at the center */
    text-decoration: none; /* Remove underline */
    color: white;
    padding: 10px 20px;
    background-color: #385170;
    border-radius: 5px;
    font-weight: bold; /* Make the text bold */
}


</style>

<div class="card w-100" style="height: 100vh;">
    <div class="card-header">
        <a href="#" class="blue-button"><h3>Material Return view</h3></a>
    </div>

    <div class="card-body">
        <div class="search-form">
            <div class="form-group">
                <label for="materialSearch">Search by Material Name:</label>
                <input type="text" class="form-control" id="materialSearch" placeholder="Material Name">
            </div>
            <div class="form-group">
                <label for="brandSearch">Search by Brand:</label>
                <input type="text" class="form-control" id="brandSearch" placeholder="Brand">
            </div>
        </div>
        <div class="material-count">
            <p>Total Materials: 3</p> <!-- Update the count dynamically if needed -->
        </div>
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Material Name</th>
                    <th>Brand</th>
                    <th>Quantity</th>
                    <th>Unit of Measurement</th>
                    <th>Date of Return</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Window Regulator</td>
                    <td>TATA</td>
                    <td>10</td>
                    <td>pieces</td>
                    <td>2024-05-01</td>
                    <td>A window regulator is a mechanical device . </td>
                    <td style="padding: 5px;">
    <button class="btn btn-primary">Edit</button>
</td>
<td style="padding: 5px;">
    <button class="btn btn-danger">Delete</button>
</td>

                </tr>
                <tr>
                    <td>Wheel Arch</td>
                    <td>TATA</td>
                    <td>5</td>
                    <td>pieces</td>
                    <td>2024-05-03</td>
                    <td>The wheel arch, also known as the wheel well or fender well</td>
                    <td style="padding: 5px;">
    <button class="btn btn-primary">Edit</button>
</td>
<td style="padding: 5px;">
    <button class="btn btn-danger">Delete</button>
</td>

                </tr>
                <tr>
                    <td>Headlight Assembly</td>
                    <td>TATA</td>
                    <td>20</td>
                    <td>pieces</td>
                    <td>2024-05-05</td>
                    <td>A headlight assembly is a component of a vehicle's lighting .</td>
                    <td style="padding: 5px;">
    <button class="btn btn-primary">Edit</button>
</td>
<td style="padding: 5px;">
    <button class="btn btn-danger">Delete</button>
</td>

                </tr>
                <!-- Add more rows as needed -->
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zp2lanbzry82/website.ospdemo.in/resources/views/admin/returnview.blade.php ENDPATH**/ ?>