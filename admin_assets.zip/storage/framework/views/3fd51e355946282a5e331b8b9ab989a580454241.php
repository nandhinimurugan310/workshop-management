<!DOCTYPE html>
<!-- Coding by CodingNepal | www.codingnepalweb.com-->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8" />
    <title>Login and Registration Form in HTML & CSS | CodingLab</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/style.css')); ?>" />
    <!-- Fontawesome CDN Link -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
      .bg-image-vertical {
        position: relative;
        overflow: hidden;
        background-repeat: no-repeat;
        background-position: right center;
        background-size: auto 100%;
      }

      @media (min-width: 1025px) {
        .h-custom-2 {
          height: 100%;
        }
      }
    </style>
  </head>

  <body>
    <section class="vh-100">
      <div class="container-fluid mt-6 pt-5">
        <div class="row">
          <div class="col-sm-6 text-black">

            <div
              class="d-flex align-items-center h-custom-2 px-5 ms-xl-4 pt-xl-0 mt-xl-n5"
            >
              <form style="width:25rem ml-4">
                <h1 style="width:30rem" class="fw-normal mb-3" style="letter-spacing:1px">
                  Welcome To Warehouse Management Portal
                </h1>

                <div data-mdb-input-init class="form-outline mb-4">
                  <input
                    type="email"
                    id="form2Example18"
                    class="form-control form-control-lg"
                  />
                  <label class="form-label" for="form2Example18"
                    >Email address</label
                  >
                </div>

                <div data-mdb-input-init class="form-outline mb-4">
                  <input
                    type="password"
                    id="form2Example28"
                    class="form-control form-control-lg"
                  />
                  <label class="form-label" for="form2Example28"
                    >Password</label
                  >
                </div>

                <div class="pt-1 mb-4">
                  <button
                    data-mdb-button-init
                    data-mdb-ripple-init
                    class="btn btn-lg btn-block"
                    type="button" style="background-color: #F3BD00;width:15rem"
                    
                  >
                    Login
                  </button>
                </div>

                <!-- <p class="small mb-5 pb-lg-2">
                  <a class="text-muted" href="#!">Forgot password?</a>
                </p> -->
                <!-- <p>
                  Don't have an account?
                  <a href="#!" class="link-info">Register here</a>
                </p> -->
              </form>
            </div>
          </div>
          <div class="col-sm-6 d-none d-sm-block">
            <img
              src="<?php echo e(asset('assets/img/g7.jpeg')); ?>"
              alt="Login image"
              class="w-100 vh-95"
              style="object-fit: cover; object-position: center"
            />
          </div>
        </div>
      </div>
    </section>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\sakthi body works\sakthi\resources\views/user/login.blade.php ENDPATH**/ ?>