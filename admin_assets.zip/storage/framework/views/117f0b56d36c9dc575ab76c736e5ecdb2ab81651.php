

<?php $__env->startSection('content'); ?>

<style>
    .card {
        width: 95%;
        max-width: 1200px;
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        overflow-y: auto;
    }

 
    .card {
        width: 100%;
        height: auto; /* Adjust height automatically based on content */
        margin: 20px auto;
        padding: 20px;
        border: 1px solid #ccc;
        overflow-y: auto;
    }


    .image-box {
        border: 5px solid #ccc;
        padding: 10px;
        height: 200px;
        width: 300px;
        overflow-y: auto;
        margin-bottom: 20px;
    }

    .column-container {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
    }

    .column-container div {
        width: 48%;
    }
    .print-button {
    display: inline-block;
    padding: 8px 16px;
    background-color: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.print-button:hover {
    background-color: #0056b3;
}

.blue-button {
    background-color: blue;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    text-decoration: none;
    display: block; /* Change display property to block */
    width: 100%; /* Set width to 100% */
    box-sizing: border-box; /* Ensure padding is included in the width */
    text-align: left; /* Align text to the right */
}

button {
    background-color: purple;
    color: white;
    padding: 8px 16px; /* Adjust padding to reduce button size */
    border: none;
    border-radius: 5px;
    text-decoration: none;
    display: inline-block;
    margin-top: 5px; /* Adjust margin as needed */
    cursor: pointer;
    font-size: 14px; /* Adjust font size */
}
</style>
<div class="card">
    <div class="card-header">
    <a href="#" class="blue-button"><h3>Purchase Order Allocation</h3></a>
        <!-- <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Vehicle Service Analysis</a></li>
                <li class="breadcrumb-item active" aria-current="page">Purchase Order Create</li>
            </ol>
        </nav> -->
    </div>


    <div>
        <!-- Search input -->
        <label for="searchInput" class="highlight">Search by Vehicle Number:</label>
        <input type="text" id="searchInput">
        <button id="searchButton">Search</button>

        <!-- Right side, initially hidden -->
        <div id="additionalFields" class="card" style="display: none; margin-top: 10px;">
            <div class="column-container">
                <div>
                    <label class="highlight"><strong>Vehicle number:</strong></label>
                    <span id="vehicleNumber"></span><br>
                    <label class="highlight"><strong>Vehicle reviewed by:</strong></label>
                    <span id="vehicleReviewedBy"></span><br>
                    <label class="highlight"><strong>Reviewed date:</strong></label>
                    <span id="reviewedDate"></span><br>
                    <label class="highlight"><strong>Customer name:</strong></label>
                    <span id="customerName"></span><br>
                    <label class="highlight"><strong>Customer mobile:</strong></label>
                    <span id="customerMobile"></span><br>
                    <label class="highlight"><strong>Private or government vehicle:</strong></label>
                    <span id="vehicleType"></span><br>
                    <label class="highlight"><strong>Type of work:</strong></label>
                    <span id="workType"></span><br>
                    <label class="highlight"><strong>Work description:</strong></label>
                    <span id="workDescription"></span><br>
                </div>
                <div>
                  
                    <!-- Image field -->
                    <label class="highlight"><strong>Image:</strong></label>
                    <div class="image-box">
                        <div class="image-container">
                            <img src="" alt="Image" id="vehicleImage">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="materialSupplierAllocation" class="card" style="display: none; margin-top: 20px;">
        <div class="card-header">
        <h4 style="background-color: yellow; color: black; padding: 10px;">Material Supplier Allocation</h4>

        </div>
        <div class="card-body" style="display: flex; justify-content: space-between;">
            <!-- First card -->
            <div class="card" style="background-color: lightblue; border: 2px solid blue;">
    <div><span class="highlight">Supplier 1</span></div>
    <div>Price: ₹100</div>
    <div>Date: 2024-05-13</div>
</div>
<div class="card" style="background-color: lightblue; border: 2px solid blue;">
    <div><span class="highlight">Supplier 2</span></div>
    <div>Price: ₹150</div>
    <div>Date: 2024-05-14</div>
</div>
<div class="card"style="background-color: lightblue; border: 2px solid blue;">
    <div><span class="highlight">Supplier 3</span></div>
    <div>Price: ₹120</div>
    <div>Date: 2024-05-15</div>
</div>
<div class="card"style="background-color: lightblue; border: 2px solid blue;">
    <div><span class="highlight">Supplier 4</span></div>
    <div>Price: ₹90</div>
    <div>Date: 2024-05-16</div>
</div>
        </div>
    </div>

    <div class="card" id="materialAllocationTable" style="display: none; margin-top: 20px;">
        <div class="card-header">
            <h4 style="background-color: yellow; color: black; padding: 10px;">Material Allocation</h4>
        </div>
        <div class="card-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Material Name</th>
                        <th>Supplier</th>
                        <th>Quantity</th>
                        <th>Unit of Measurement</th>
                        <th>Brand</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Headlight Assembly</td>
                        <td>
                            <select>
                                <option>Supplier 1</option>
                                <option>Supplier 2</option>
                                <option>Supplier 3</option>
                                <option>Supplier 4</option>
                            </select>
                        </td>
                        <td>2</td>
                        <td>pieces</td>
                        <td>Volvo</td>
                        <td>
                            <button>Edit</button>
                            <button>Delete</button>
                        </td>
                    </tr>
                    <tr>
                        <td>Taillight Assembly</td>
                        <td>
                            <select>
                                <option>Supplier 1</option>
                                <option>Supplier 2</option>
                                <option>Supplier 3</option>
                                <option>Supplier 4</option>
                            </select>
                        </td>
                        <td>2</td>
                        <td>pieces</td>
                        <td>Volvo</td>
                        <td>
                            <button>Edit</button>
                            <button>Delete</button>
                        </td>
                    </tr>
                    <tr>
                        <td>Door Panel</td>
                        <td>
                            <select>
                                <option>Supplier 1</option>
                                <option>Supplier 2</option>
                                <option>Supplier 3</option>
                                <option>Supplier 4</option>
                            </select>
                        </td>
                        <td>4</td>
                        <td>pieces</td>
                        <td>Volvo</td>
                        <td>
                            <button>Edit</button>
                            <button>Delete</button>
                        </td>
                    </tr>
                    <!-- Add more rows as needed with sample data -->
                </tbody>
            </table>
        </div>
    </div>

    <div class="card" style="margin-top: 20px;">
        <div id="summary" style="display: none;">
            <span class="highlight">Total Materials Allocated: </span><span id="totalMaterials"></span>
            <span class="highlight" style="margin-left: 20px;">Total Suppliers: </span><span id="totalSuppliers"></span>
        </div>

        <div id="supplierButtons" style="display: none; margin-top: 20px;">
    <button id="supplier1Button" style="margin-right: 50px;" onclick="showSupplierData('supplier1')">Supplier 1</button>
    <button id="supplier2Button" style="margin-right: 50px;" onclick="showSupplierData('supplier2')">Supplier 2</button>
    <button id="supplier3Button" onclick="showSupplierData('supplier3')">Supplier 3</button>
</div>

<div id="supplierDetails" style="display: none;">
    <!-- Material details will be displayed dynamically here -->
    <button class="print-button" onclick="printSupplierDetails()">Print</button>
    <button class="save-button" >save</button>
    <table class="table" id="supplierDetailsTable">
        <thead>
            <tr>
                <th>Material</th>
                <th>Price</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <!-- Supplier details will be inserted here dynamically -->
        </tbody>
    </table>
</div>
  </div>
    <div style="margin-top: 20px; text-align: center;">
    <button onclick="createPO()">Create PO</button>
</div>
</div>



<script>
  
    // Function to handle the search button click event
    document.getElementById("searchButton").addEventListener("click", function() {
        var searchValue = document.getElementById("searchInput").value.trim();
        if (searchValue !== "") {
            simulateDataRetrieval(searchValue);
        } else {
            alert("Please enter a vehicle number to search.");
        }
    });

    // Function to simulate data retrieval based on the search value
    function simulateDataRetrieval(searchValue) {
        // For demonstration purposes, let's assume we have retrieved data for the searched vehicle
        var vehicleData = {
            vehicleNumber: "TN 13 AD 7508",
            vehicleReviewedBy: "Sudhan",
            reviewedDate: "2024-05-13",
            customerName: "Alice",
            customerMobile: "1234567890",
            vehicleType: "Private",
            workType: "Repair",
            workDescription: "Engine Tune-up",
            imageUrl: "image.jpg"
        };

        // Display the retrieved data
        displayData(vehicleData);
    }

    // Function to display the retrieved data
    function displayData(vehicleData) {
        // Show the additional fields section
        var additionalFields = document.getElementById("additionalFields");
        additionalFields.style.display = "block";

        // Update the additional fields with the retrieved data
        document.getElementById("vehicleNumber").textContent = vehicleData.vehicleNumber;
        document.getElementById("vehicleReviewedBy").textContent = vehicleData.vehicleReviewedBy;
        document.getElementById("reviewedDate").textContent = vehicleData.reviewedDate;
        document.getElementById("customerName").textContent = vehicleData.customerName;
        document.getElementById("customerMobile").textContent = vehicleData.customerMobile;
        document.getElementById("vehicleType").textContent = vehicleData.vehicleType;
        document.getElementById("workType").textContent = vehicleData.workType;
        document.getElementById("workDescription").textContent = vehicleData.workDescription;
        document.getElementById("vehicleImage").src = vehicleData.imageUrl;

        // Show the material supplier allocation section
        var materialSupplierAllocation = document.getElementById("materialSupplierAllocation");
        materialSupplierAllocation.style.display = "block";

        // Show the material allocation table
        var materialAllocationTable = document.getElementById("materialAllocationTable");
        materialAllocationTable.style.display = "block";

        // Show the summary section
        var summary = document.getElementById("summary");
        summary.style.display = "block";

        // Show the supplier buttons
        var supplierButtons = document.getElementById("supplierButtons");
        supplierButtons.style.display = "block";

        // Add event listeners to supplier buttons
        document.getElementById("supplier1Button").addEventListener("click", function() {
            showSupplierData("Supplier 1");
        });
        document.getElementById("supplier2Button").addEventListener("click", function() {
            showSupplierData("Supplier 2");
        });
        document.getElementById("supplier3Button").addEventListener("click", function() {
            showSupplierData("Supplier 3");
        });
    }

    // Function to display material details for a specific supplier
    function showSupplierData(supplier) {
        // Display the supplier details div
        document.getElementById('supplierDetails').style.display = 'block';
        
        // Clear previous data in the table
        clearSupplierDetails();

        // Example data for each supplier
        var data = {
            'Supplier 1': [
                { supplier: 'Bumper', price: '₹100', date: '2024-05-14' },
                { supplier: 'Side Mirror', price: '₹120', date: '2024-05-15' },
                // Add more data for Supplier 1 if needed
            ],
            'Supplier 2': [
                { supplier: 'Supplier 2', price: '₹150', date: '2024-05-14' },
                { supplier: 'Supplier 2', price: '₹130', date: '2024-05-15' },
                // Add more data for Supplier 2 if needed
            ],
            'Supplier 3': [
                { supplier: 'Supplier 3', price: '₹200', date: '2024-05-14' },
                { supplier: 'Supplier 3', price: '₹180', date: '2024-05-15' },
                // Add more data for Supplier 3 if needed
            ]
        };

        // Populate the table with data for the selected supplier
        var tableBody = document.getElementById('supplierDetailsTable').getElementsByTagName('tbody')[0];
        data[supplier].forEach(function(item) {
            var row = tableBody.insertRow();
            var cell1 = row.insertCell(0);
            var cell2 = row.insertCell(1);
            var cell3 = row.insertCell(2);
            cell1.innerHTML = item.supplier;
            cell2.innerHTML = item.price;
            cell3.innerHTML = item.date;
        });
    }

    function clearSupplierDetails() {
        // Clear previous data in the table
        var tableBody = document.getElementById('supplierDetailsTable').getElementsByTagName('tbody')[0];
        tableBody.innerHTML = '';
    }

    function printSupplierDetails() {
        // Your print logic here
        window.print();
    }


</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sakthi body works\sakthi\resources\views/admin/purchaseorder.blade.php ENDPATH**/ ?>