<style>
.footer {
  background-color: #f8f9fa; /* Optional: add a background color if needed */
  padding: 1rem 0;
}

.footer .text-black {
  color: black;
}

.footer .text-center {
  text-align: center;
}

</style>


<footer class="footer">
  <div class="d-flex justify-content-center align-items-center flex-column flex-sm-row text-black">
    <span class="text-center mb-1 mb-sm-0">&copy; 2024. All rights reserved.</span>
    <span class="text-center ms-sm-3">Developed by Accelerated Development Machines Pvt. Ltd</span>
  </div>
</footer>

                  