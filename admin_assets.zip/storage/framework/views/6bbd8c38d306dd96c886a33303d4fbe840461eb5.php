

<?php $__env->startSection('content'); ?>
    <style>
        .bg-custom {
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            /* Align text at the center */
            text-decoration: none;
            /* Remove underline */
            color: white;
            padding: 10px 20px;
            background-color: #385170;
            border-radius: 5px;
            font-weight: bold;
            /* Make the text bold */
        }
    </style>
    <div class="container p-6">
        <h1 class="mt-4 mb-2 bg-custom">Edit Material</h1>

        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label for="vehicleNumber">Vehicle Number</label>
                    <input type="text" class="form-control" id="vehicleNumber">
                </div>
            </div>
            <div class="col-md-6">
                <button class="btn btn-primary mt-4" id="searchButton">Search</button>
            </div>
        </div>

        <div id="material_container" class="p-2" style="display:none;">
            <div class="row mt-3 p-3">
                <div class="row">
                    <div class="col-md-9">
                        <div class="row">
                            <!-- First Row: Vehicle Number, Customer Name, Contact Number -->
                            <div class="col-md-4 mb-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h6 class="card-title">Vehicle Number</h6>
                                        <p class="card-text">TN O7 BS 7571</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Customer Name</h5>
                                        <p class="card-text">Raju</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Contact Number</h5>
                                        <p class="card-text">9876543212</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <!-- Second Row: Vehicle Type, Reviewed By, Review Date -->

                            <div class="col-md-4 mb-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Reviewed By</h5>
                                        <p class="card-text">Sub-Manager</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Review Date</h5>
                                        <p class="card-text">2024-05-16</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4 mb-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Vehicle Type</h5>
                                        <p class="card-text">TATA-ACE</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <img src="<?php echo e(asset('assets/images/image2.jpeg')); ?>">
                    </div>
                </div>
               <div class="col-md-12">
                    <h4 class=" mt-3 mb-2 bg-custom" style="background-color: #5585b5">Material Requirement</h4>
                    <!-- Table to display search results -->
                      <button class="btn btn-primary text-right">Edit</button>
                    <table id="dataTable" class="table">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Material Name</th>
                                <th>Brand</th>
                                <th>Quantity</th>
                                <th>Unit of Measurement</th>
                                <th>Action</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Material A</td>
                                <td>Brand X</td>
                                <td>100</td>
                                <td>Kg</td>
                                <td>
                                   
                                    <button class="btn btn-danger">Delete</button>
                                </td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Material B</td>
                                <td>Brand Y</td>
                                <td>150</td>
                                <td>Liter</td>
                                <td>
                                   
                                    <button class="btn btn-danger">Delete</button>
                                </td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Material C</td>
                                <td>Brand Z</td>
                                <td>200</td>
                                <td>Piece</td>
                                <td>
                                  
                                    <button class="btn btn-danger">Delete</button>
                                </td>
                            </tr>
                            <!-- Add more rows as needed -->
                        </tbody>
                    </table>



                </div>
                <!-- Pagination -->
                <nav aria-label="Page navigation example">
                    <ul id="pagination" class="pagination">
                        <!-- Pagination links will be added dynamically here -->
                    </ul>
                </nav>



            <div class="row mt-1 p-4">
               <div class="col-md-12">
                   <button class="btn btn-success px-2" id="createButton">Save</button>
               </div>
           </div>

        </div>

    </div>

    <script>
        document.getElementById('searchButton').addEventListener('click', function() {
            document.getElementById('material_container').style.display = 'block';
        });

        function paginateTable() {
            const table = document.getElementById('dataTable');
            const rows = table.rows.length; // Number of rows in the table
            const rowsPerPage = 2; // Number of rows per page
            const pageCount = Math.ceil(rows / rowsPerPage); // Calculate number of pages

            // Clear previous pagination
            const pagination = document.getElementById('pagination');
            pagination.innerHTML = '';

            // Create pagination links
            for (let i = 1; i <= pageCount; i++) {
                const li = document.createElement('li');
                li.classList.add('page-item');
                const a = document.createElement('a');
                a.classList.add('page-link');
                a.href = '#';
                a.textContent = i;
                a.addEventListener('click', function() {
                    showPage(i);
                });
                li.appendChild(a);
                pagination.appendChild(li);
            }

            // Show the first page by default
            showPage(1);
        }

        function showPage(pageNumber) {
            const table = document.getElementById('dataTable');
            const rows = table.rows.length;
            const rowsPerPage = 2;

            // Calculate the range of rows to show based on the page number
            const start = (pageNumber - 1) * rowsPerPage;
            const end = Math.min(start + rowsPerPage, rows);

            // Show or hide rows based on the range
            for (let i = 0; i < rows; i++) {
                table.rows[i].style.display = i >= start && i < end ? '' : 'none';
            }
        }
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/zp2lanbzry82/website.ospdemo.in/resources/views/admin/edit.blade.php ENDPATH**/ ?>