

<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vehicle Service Form</title>
</head>
<body>
<div class="main p-3">
            <div class="text-center">
                <h1>
                Welcome to Dashboard
                </h1>
                <p>This is your dashboard where you can manage various aspects of your vehicle service.</p>
            </div>
        </div>
   
</body>
</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sakthi body works\sakthi\resources\views/admin/index.blade.php ENDPATH**/ ?>